<?php $__env->startSection('title', 'halaman utama'); ?>
<?php $__env->startSection('content'); ?>

    <div class="kerja">
        <div class="container">
            <div class="col-sm-12">
                <h1 class="text-center"><b>SELAMAT DATANG DI WEBSITE KARTU PRAKERJA</b></h1>
            </div>
        </div>
    </div>
    <br>
    <br>

    <div class="profilekerja">
        <div class="container">
            <div class="col-sm-12 text-center">
                <img src="/img/prakerja_kartu.jpg" class="img-fluid">
                <br>
                <p class="text-muted"><i>Ilustrasi Kartu Prakerja.</i></p>
                <br>
                <p>Kartu Prakerja merupakan program baru yang dibuat oleh pemerintah Indonesia dalam hal guna untuk<br>
                menanggulangi masalah pengangguran yang marak terjadi saat ini. Dengan kartu prakerja maka setiap<br>
                masyarakat Indonesia berhak untuk mendapatkan lapangan pekerjaan sesuai dengan bidang/keahlian masing-masing pihak.<br>
                Mari daftar kartu prakerja sekarang juga!</p>
                <br>

                <a href="<?php echo e(route('prakerja.create')); ?>" class="btn btn-primary">Daftarkan Dirimu Disini</a>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rizal/Documents/kartu_prakerja/resources/views/data/home.blade.php ENDPATH**/ ?>