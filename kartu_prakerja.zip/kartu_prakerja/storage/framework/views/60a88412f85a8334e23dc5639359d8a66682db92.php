<?php $__env->startSection('title', 'halaman data prakerja'); ?>
<?php $__env->startSection('content'); ?>


<h1 class="text-center">Data Kartu Prakerja</h1>
  <br>
  <hr>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="card-body">
                    <a href="<?php echo e(route('prakerjas.home')); ?>" class="btn btn-primary">Kembali Ke Home</a>
                    <br>
                    <br>

                    <?php if(session()->has('pesan')): ?>
                      <div class="alert alert-success">
                          <?php echo e(session()->get('pesan')); ?>

                      </div>
                    <?php endif; ?>

                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th scope="col">ID</th>
                          <th scope="col">Nama</th>
                          <th scope="col">Foto</th>
                          <th scope="col">Detail</th>
                        
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $prakerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tampil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($tampil->nama); ?></td>
                        <td><img src="<?php echo e(Storage::url($tampil->foto)); ?>" alt="" style="width: 150px;"></td>
                        <td><a href="<?php echo e(route('prakerjas.show', ['kartu_prakerja' => $tampil->id])); ?>" class="btn btn-info">Detail</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
            </div>
        </div>
    </div>    


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rizal/Documents/kartu_prakerja/resources/views/data/index.blade.php ENDPATH**/ ?>