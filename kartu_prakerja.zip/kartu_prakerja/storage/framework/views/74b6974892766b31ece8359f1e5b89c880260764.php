<?php $__env->startSection('title', 'halaman detail data prakerja'); ?>
<?php $__env->startSection('content'); ?>


<h1 class="h2 mr-auto">Detail <?php echo e($kartu_prakerja->nama); ?></h1>
  <a href="<?php echo e(route('prakerjas.edit', ['kartu_prakerja' => $kartu_prakerja->id])); ?>" class="btn btn-info">Edit</a>

  <form action="<?php echo e(route('prakerjas.destroy', ['kartu_prakerja' => $kartu_prakerja->id])); ?> " method="POST">
    <?php echo method_field('DELETE'); ?>
    <?php echo csrf_field(); ?>
    <button type="submit" class="btn btn-danger">Hapus</button>
  </form>
  <br>
  <hr>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="card-body">
                    <ul>
                      <li><?php echo e($kartu_prakerja->no_ktp); ?></li>
                      <li><?php echo e($kartu_prakerja->nama); ?></li>
                      <li><?php echo e($kartu_prakerja->alamat); ?></li>
                      <li><?php echo e($kartu_prakerja->nama_ortu); ?></li>
                      <li><?php echo e($kartu_prakerja->nominal); ?></li>
                      <li><?php echo e($kartu_prakerja->program == '' ? 'N/A' : $kartu_prakerja->program); ?></li>
                      <li><img src="<?php echo e(Storage::url($kartu_prakerja->foto)); ?>" alt="" style="width: 150px;"></li>
                    </ul>
                  </div>
            </div>
        </div>
    </div>    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rizal/Documents/kartu_prakerja/resources/views/data/show.blade.php ENDPATH**/ ?>