<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/prakerjas', 'KartuPrakerjaController@index')->name('prakerjas.index');

Route::get('/prakerjas/home', 'KartuPrakerjaController@home')->name('prakerjas.home');

Route::get('/prakerjas/create', 'KartuPrakerjaController@create')->name('prakerja.create');

Route::get('/prakerjas/{kartu_prakerja}', 'KartuPrakerjaController@show')->name('prakerjas.show');

// Route::get('/prakerjas/tambah', 'KartuPrakerjaController@tambah')->name('prakerjas.tambah');


Route::get('/prakerjas/{kartu_prakerja}/edit', 'KartuPrakerjaController@edit')->name('prakerjas.edit');

Route::patch('/prakerjas/{kartu_prakerja}', 'KartuPrakerjaController@update')->name('prakerjas.update');

Route::delete('/prakerjas/{kartu_prakerja}', 'KartuPrakerjaController@destroy')->name('prakerjas.destroy');

Route::post('/prakerjas', 'KartuPrakerjaController@store')->name('prakerja.store');





