<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class kartu_prakerja extends Model
{
    use SoftDeletes;

    protected $fillable = ['no_ktp', 'nama', 'alamat', 'nama_ortu', 'nominal', 'program', 'foto' ];


    // protected $guarded = [];
}
