<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use App\Models\kartu_prakerja;

class GalleryRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(kartu_prakerja $kartu_prakerja)
    {
        $item = kartu_prakerja::where('no_ktp','=',$this->no_ktp)->first();
        return [
            'no_ktp'=>[
                'required',
                Rule::unique('kartu_prakerjas','no_ktp')->ignore($item['id']),
            ],
            'nama'=>'required|min:5|max:30',
            'alamat'=>'required',
            'nama_ortu'=>'required|min:5|max:30',
            'nominal'=>'required',
            'program'=>'required',
            'foto'=>'required|file|image|max:1000'
        ];
    }
}