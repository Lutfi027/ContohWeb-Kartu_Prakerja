<?php

namespace App\Http\Controllers;
use App\Models\kartu_prakerja;
use Storage;


use Illuminate\Http\Request;
use App\Http\Requests\GalleryRequest;
use Validator;
use Illuminate\Validation\Rule;

class KartuPrakerjaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $prakerja = kartu_prakerja::all();
        return view('data.index', ['prakerja' => $prakerja]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('data.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(GalleryRequest $request)
    {
        $prakerja = $request->all();
        $prakerja['foto'] = $request->file('foto')->store('assests/gallery', 'public');

        kartu_prakerja::create($prakerja);
        $request->session()->flash('pesan',"Data {$prakerja['nama']} berhasil disimpan");
        return redirect()->route('prakerjas.index');
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\kartu_prakerja  $kartu_prakerja
     * @return \Illuminate\Http\Response
     */
    public function show(kartu_prakerja $kartu_prakerja)
    {
        // $prakerja = kartu_prakerja::findOrFail($prakerja);
        return view('data.show', ['kartu_prakerja' => $kartu_prakerja]);
    }



    public function home(){
        return view('data.home');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\kartu_prakerja  $kartu_prakerja
     * @return \Illuminate\Http\Response
     */
    public function edit(kartu_prakerja $kartu_prakerja)
    {
        return view('data.edit', ['kartu_prakerja' => $kartu_prakerja]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\kartu_prakerja  $kartu_prakerja
     * @return \Illuminate\Http\Response
     */
    public function update(GalleryRequest $request, kartu_prakerja $kartu_prakerja)
    {
        $prakerja = $request->all();
        
        if($request->foto){
            Storage::delete('public/'. $prakerja['foto']);
            $prakerja['foto'] = $request->file('foto')->store('assests/gallery', 'public');
        }
        
        $kartu_prakerja->update($prakerja);
        $request->session()->flash('pesan',"Data {$kartu_prakerja['nama']} berhasil diedit");
        return redirect()->route('prakerjas.index');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\kartu_prakerja  $kartu_prakerja
     * @return \Illuminate\Http\Response
     */
    public function destroy(kartu_prakerja $kartu_prakerja)
    {
        $kartu_prakerja->delete();
        return redirect("/prakerjas");
    }
}
