@extends('layout.master')
@section('title', 'halaman tambah data prakerja')
@section('content')




<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <hr>
            <form action="{{ route('prakerja.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="form-group">
                    <label for="no_ktp">Nomor KTP</label>
                    <input type="text" class="form-control @error('no_ktp') is invalid @enderror" id="no_ktp" name="no_ktp" value="{{ old('no_ktp') }}">
                    @error('no_ktp')
                        <div class="alert alert-danger">{{ $message }}</div>
                    @enderror
                </div>



                <div class="form-group">
                    <label for="nama">Nama</label>
                    <input type="text" class="form-control @error('nama') is invalid @enderror" id="nama" name="nama" value="{{ old('nama') }}">
                    @error('nama')
                        <div class="alert alert-danger">{{ $message }}</div>
                    @enderror
                </div>


                <div class="form-group">
                    <label for="alamat">Alamat</label>
                    <textarea name="alamat" id="alamat" rows="3" class="form-control">{{ old('alamat') }}</textarea>
                    @error('alamat')
                        <div class="alert alert-danger">{{ $message }}</div>
                    @enderror
                </div>


                <div class="form-group">
                    <label for="nama_ortu">Nama Orang Tua</label>
                    <input type="text" class="form-control @error('nama_ortu') is invalid @enderror" id="nama_ortu" name="nama_ortu" value="{{ old('nama_ortu') }}">
                    @error('nama_ortu')
                        <div class="alert alert-danger">{{ $message }}</div>
                    @enderror
                </div>


                <div class="form-group">
                    <label for="nominal">Nominal</label>
                    <input type="text" class="form-control @error('nominal') is invalid @enderror" id="nominal" name="nominal" value="{{ old('nominal') }}">
                    @error('nominal')
                        <div class="alert alert-danger">{{ $message }}</div>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="program">Program Yang Diikuti</label>
                    <select name="program" id="program" class="form-control">
                        <option value="Teknisi" {{ old('program') == 'Teknisi' ? 'selected' : '' }}>
                            Teknisi
                        </option>
                        <option value="Administrasi" {{ old('program') == 'Administrasi' ? 'selected' : '' }}>
                            Administrasi
                        </option>
                        <option value="Web Developer" {{ old('program') == 'Web Developer' ? 'selected' : '' }}>
                            Web Developer
                        </option>
                        <option value="Manajemen" {{ old('program') == 'Manajemen' ? 'selected' : '' }}>
                            Manajemen
                        </option>
                        <option value="Mobile Developer" {{ old('program') == 'Mobile Developer' ? 'selected' : '' }}>
                            Mobile Developer
                        </option>
                    </select>
                    @error('program')
                        <div class="alert alert-danger">{{ $message }}</div>
                    @enderror
                </div>


            
                <div class="form-group">
                    <label for="foto">Gambar Profile</label>
                    <input type="file" class="form-control-file" id="foto" name="foto">
                    @error('foto')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>
                

                <button type="submit"  class="btn-btn-primary mb-2">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>



@endsection