@extends('layout.master')
@section('title', 'halaman detail data prakerja')
@section('content')


<h1 class="h2 mr-auto">Detail {{ $kartu_prakerja->nama }}</h1>
  <a href="{{ route('prakerjas.edit', ['kartu_prakerja' => $kartu_prakerja->id]) }}" class="btn btn-info">Edit</a>

  <form action="{{ route('prakerjas.destroy', ['kartu_prakerja' => $kartu_prakerja->id]) }} " method="POST">
    @method('DELETE')
    @csrf
    <button type="submit" class="btn btn-danger">Hapus</button>
  </form>
  <br>
  <hr>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="card-body">
                    <ul>
                      <li>{{ $kartu_prakerja->no_ktp }}</li>
                      <li>{{ $kartu_prakerja->nama }}</li>
                      <li>{{ $kartu_prakerja->alamat }}</li>
                      <li>{{ $kartu_prakerja->nama_ortu }}</li>
                      <li>{{ $kartu_prakerja->nominal }}</li>
                      <li>{{ $kartu_prakerja->program == '' ? 'N/A' : $kartu_prakerja->program }}</li>
                      <li><img src="{{ Storage::url($kartu_prakerja->foto) }}" alt="" style="width: 150px;"></li>
                    </ul>
                  </div>
            </div>
        </div>
    </div>    

@endsection