@extends('layout.master')
@section('title', 'halaman data prakerja')
@section('content')


<h1 class="text-center">Data Kartu Prakerja</h1>
  <br>
  <hr>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="card-body">
                    <a href="{{ route('prakerjas.home') }}" class="btn btn-primary">Kembali Ke Home</a>
                    <br>
                    <br>

                    @if(session()->has('pesan'))
                      <div class="alert alert-success">
                          {{ session()->get('pesan') }}
                      </div>
                    @endif

                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th scope="col">ID</th>
                          <th scope="col">Nama</th>
                          <th scope="col">Foto</th>
                          <th scope="col">Detail</th>
                        
                          {{-- <th scope="col">Gambar Barang</th> --}}
                        </tr>
                      </thead>
                      <tbody>
                        @foreach($prakerja as $tampil)
                        <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $tampil->nama }}</td>
                        <td><img src="{{ Storage::url($tampil->foto) }}" alt="" style="width: 150px;"></td>
                        <td><a href="{{ route('prakerjas.show', ['kartu_prakerja' => $tampil->id]) }}" class="btn btn-info">Detail</a></td>
                        </tr>
                        @endforeach
                      </tbody>
                    </table>
                  </div>
            </div>
        </div>
    </div>    


    @endsection