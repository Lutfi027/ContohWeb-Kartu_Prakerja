@extends('layout.master')
@section('title', 'halaman bagian')
@section('content')

    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <hr>
                <form action="{{ route('prakerjas.update', $kartu_prakerja) }}" method="POST" enctype="multipart/form-data" name="edit"> 
                    @method('PATCH')
                    @csrf
                    <div class="form-group">
                        <label for="no_ktp">Nomor KTP</label>
                        <input type="text" class="form-control @error('no_ktp') is invalid @enderror" id="no_ktp" name="no_ktp" value="{{ $kartu_prakerja->no_ktp }}">
                        @error('no_ktp')
                            <div class="alert alert-danger">{{ $message }}</div>
                        @enderror
                    </div>
    
    
    
                    <div class="form-group">
                        <label for="nama">Nama</label>
                        <input type="text" class="form-control @error('nama') is invalid @enderror" id="nama" name="nama" value="{{ $kartu_prakerja->nama }}">
                        @error('nama')
                            <div class="alert alert-danger">{{ $message }}</div>
                        @enderror
                    </div>
    
    
                    <div class="form-group">
                        <label for="alamat">Alamat</label>
                        <textarea name="alamat" id="alamat" rows="3" class="form-control">{{ $kartu_prakerja->alamat }}</textarea>
                        @error('alamat')
                            <div class="alert alert-danger">{{ $message }}</div>
                        @enderror
                    </div>
    
    
                    <div class="form-group">
                        <label for="nama_ortu">Nama Orang Tua</label>
                        <input type="text" class="form-control @error('nama_ortu') is invalid @enderror" id="nama_ortu" name="nama_ortu" value="{{ $kartu_prakerja->nama_ortu }}">
                        @error('nama_ortu')
                            <div class="alert alert-danger">{{ $message }}</div>
                        @enderror
                    </div>
    
    
                    <div class="form-group">
                        <label for="nominal">Nominal</label>
                        <input type="text" class="form-control @error('nominal') is invalid @enderror" id="nominal" name="nominal" value="{{ $kartu_prakerja->nominal }}">
                        @error('nominal')
                            <div class="alert alert-danger">{{ $message }}</div>
                        @enderror
                    </div>
    
                    <div class="form-group">
                        <label for="program">Program Yang Diikuti</label>
                        <select name="program" id="program" class="form-control">
                            <option value="Teknisi" {{ $kartu_prakerja->program }}>
                                Teknisi
                            </option>
                            <option value="Administrasi" {{ $kartu_prakerja->program }}>
                                Administrasi
                            </option>
                            <option value="Web Developer" {{ $kartu_prakerja->program }}>
                                Web Developer
                            </option>
                            <option value="Manajemen" {{ $kartu_prakerja->program }}>
                                Manajemen
                            </option>
                            <option value="Mobile Developer" {{ $kartu_prakerja->program }}>
                                Mobile Developer
                            </option>
                        </select>
                        @error('program')
                            <div class="alert alert-danger">{{ $message }}</div>
                        @enderror
                    </div>
    
    
                
                    <div class="form-group">
                        <label for="foto">Gambar Profile</label>
                        <input type="file" class="form-control-file" id="foto" name="foto" value="{{ $kartu_prakerja->foto }}">
                        @error('foto')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                    
    
                    <button type="submit"  class="btn-btn-primary mb-2">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

@endsection