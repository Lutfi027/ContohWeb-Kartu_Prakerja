<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateKartuPrakerjasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('kartu_prakerjas', function (Blueprint $table) {
            $table->id();
            $table->char('no_ktp', 10)->unique();
            $table->string('nama');
            $table->text('alamat');
            $table->string('nama_ortu');
            $table->char('nominal');
            $table->char('program');
            $table->string('foto');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('kartu_prakerjas');
    }
}
